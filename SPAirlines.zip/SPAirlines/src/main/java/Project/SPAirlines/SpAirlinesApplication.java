package Project.SPAirlines;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpAirlinesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpAirlinesApplication.class, args);
	}

}
